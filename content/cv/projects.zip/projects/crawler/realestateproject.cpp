#include "realestateproject.h"

RealEstateProject::RealEstateProject(QObject *parent) :
    QObject(parent)
{
}

void RealEstateProject::setId(QString id)
{
    this->id = id;
}

void RealEstateProject::setLink(QString url) {
    link = url;
}

void RealEstateProject::setCatalogImage(QString url) {
    catalogImage = url;
}

void RealEstateProject::setType(int type)
{
    if ((type < 1) or (type > 5)) {
        qWarning() << "For project " << this->id << " type is " << type;
    }
    this->type = type;
}

void RealEstateProject::setTitleImage(QString url) {
    titleImage = url;
}

void RealEstateProject::addSideImage(QString url) {
    sideImages.append(url);
}

void RealEstateProject::setArea(QString area) {
    this->area = area;
}

void RealEstateProject::addToDescriptionTable(QString term, QString description) {
    QPair<QString, QString> descriptionItem;
    descriptionItem.first = term;
    descriptionItem.second = description;
    descriptionTable.append(descriptionItem);
}

void RealEstateProject::addToFloorDescription(QString term, QString imageUrl) {
    QPair<QString, QString> floorItem;
    floorItem.first = term;
    floorItem.second = imageUrl;
    floorDescription.append(floorItem);
}
