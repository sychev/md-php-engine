#include <QCoreApplication>
#include "crawler.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    Crawler *crawler;
    crawler = new Crawler(&a);
    
    return a.exec();
}
