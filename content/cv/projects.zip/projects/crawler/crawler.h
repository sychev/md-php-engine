#ifndef CRAWLER_H
#define CRAWLER_H

#include <QObject>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include "realestateproject.h"

class Crawler : public QObject
{
    Q_OBJECT
public:
    explicit Crawler(QObject *parent = 0);
    void addToDownloadList(QString url);

private slots:
    void replyFinished(QNetworkReply* reply);

private:
    QList<QString> downloadList;
    QNetworkAccessManager *manager;
    void requestPage(int pageNumber);
    static const QString CatalogURL;
    static const int endPage;
    static const int fromPage;
    void readAllProjectsLinks();
    void startDownloadingProjectsLinks();
    void parseCatalogPageContent(QString pageHtml);
    QStringList projectLinks;
    void createRealEstateObject(QString linkUrl, QString catalogImageUrl);
    QList<RealEstateProject*> realEstateProjectList;
    QString getTextFromCode(QString string, QString startingMarker, QString breakingMarker);
    void createDir(QString dirPath);
    int getTypeOfPlan(QString pageContent);
    QString getProjectId(QString pageContent);
    QString getProjectIdFromUrl(QString url);
    void saveFileFromReply(QString fileName, QNetworkReply* reply);
    void saveStringToFile(QString fileName, QString string);
    void addFacadeImageToDownloadQueue(QString projectPageContent);
    void addFloorHeightToDownloadQueue(QString projectPageContent);
    void addFloorPlanToDownloadQueue(QString projectPageContent);
    QString getFileNameFromUrl(QString url);
    void downloadNextLinkFromQueue();
};

#endif // CRAWLER_H
