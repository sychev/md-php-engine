#include <QDebug>
#include <QtCore>
#include <QtNetwork>

#include "crawler.h"
const QString Crawler::CatalogURL = "http://plans.ru/list.php?new&s=0&e=9999";
const int Crawler::endPage(127);
const int Crawler::fromPage(1);

Crawler::Crawler(QObject *parent) :
    QObject(parent)
{
    manager = new QNetworkAccessManager(this);
    connect(manager, SIGNAL(finished(QNetworkReply*)),
        this, SLOT(replyFinished(QNetworkReply*)));

    manager->get(QNetworkRequest(QUrl(CatalogURL)));
}

void Crawler::addToDownloadList(QString url)
{
    if (!downloadList.contains(url)) {
        //qDebug() << url << " was added to download list.";
        downloadList.append(url);
    }
}

void Crawler::replyFinished(QNetworkReply* reply)
{
    if (reply->error() == QNetworkReply::NoError) {
        QString url = reply->request().url().toString();
        qDebug() << "Downloaded: " << reply->request().url().toString();
        // qDebug() << reply->request().url().toString() << " =?= " << QString("http://plans.ru/list.php?page=%1").arg(totalNumOfPages);
        if (url == CatalogURL) {
            qDebug() << "Got the catalog output\n";
            saveFileFromReply("./page1.html", reply);
            if (fromPage < 2) {
                requestPage(2);
            } else {
                requestPage(fromPage);
            }
            return;
        } else if (url == QString("http://plans.ru/list.php?page=%1").arg(endPage)) {
            // последняя страница каталога была скачана
            saveFileFromReply(QString("./page%1.html").arg(endPage), reply);
            readAllProjectsLinks();
            startDownloadingProjectsLinks();
            return;
        } else if (url.contains("/list.php?page=")) {

            int pageNumber;
            pageNumber = url.remove("http://plans.ru/list.php?page=").toInt();
            saveFileFromReply(QString("./page%1.html").arg(pageNumber), reply);

            if (pageNumber < endPage) {
                requestPage(++pageNumber);
            }
            return;

        } else if (url.contains("/project.php?id=")) {
            // мы только что скачали страницу с проектом
            QString replyContent;
            replyContent = replyContent.fromLocal8Bit(reply->readAll());
            int type = getTypeOfPlan(replyContent);
            QString projectId = getProjectId(replyContent);
            //qDebug() << "Project id from page content = " << projectId << " Type = " << type;
            createDir(projectId);
            saveStringToFile("./" + projectId + "/project.html", replyContent);
            //saveStringToFile("./00-00/project.html", replyContent);
            addFacadeImageToDownloadQueue(replyContent);
            addFloorHeightToDownloadQueue(replyContent);
            addFloorPlanToDownloadQueue(replyContent);
        } else if (url.contains("/images/f/")) {
            // картинки с фасадом дома
            QString projectId = getProjectIdFromUrl(url);
            createDir(projectId);

            // ./images/f/50-39_f2.jpg -> ./50-39/facade2.jpg
            QString fileName = "./" + projectId + "/facade" + url.mid(url.size() - 5);
            saveFileFromReply(fileName, reply);
        } else if (url.contains("/images/v/")) {
            // картинка с высотой дома
            QString projectId = getProjectIdFromUrl(url);
            createDir(projectId);

            // /images/v/50-39_1.jpg -> ./50-39/floor.jpg
            QString fileName = "./" + projectId + "/floor" + url.mid(url.size() - 4);
            saveFileFromReply(fileName, reply);
        } else if (url.contains("/images/projects/")) {
            // картинки с планами этажей и перспективой
            QString projectId = getProjectIdFromUrl(url);
            createDir(projectId);

            // /images/projects/50-39_1.jpg -> ./50-39/view1.jpg
            QString fileName = "./" + projectId + "/view" + url.mid(url.size() - 5);

            // in case of main picture, where filename is /images/projects/50-39.jpg
            if (url.contains(projectId + ".jpg")) {
                fileName = "./" + projectId + "/main.jpg";
            }
            saveFileFromReply(fileName, reply);
        }
        downloadList.removeAll(url);
    } else {
        qDebug() << "Network error: " << reply->errorString();
    }

    downloadNextLinkFromQueue();
}

void Crawler::requestPage(int pageNumber)
{
    QNetworkRequest *request = new QNetworkRequest;
    request->setRawHeader("Referer", "http://plans.ru/list.php?new&s=0&e=9999");
    QString url = QString("http://plans.ru/list.php?page=%1").arg(pageNumber);
    request->setUrl(QUrl(url));
    manager->get(*request);
}

void Crawler::readAllProjectsLinks()
{
    //qDebug() << "Start reading links";
    QDir myDir("./");
    QStringList nameFilters("page*.html");
    myDir.setNameFilters(nameFilters);
    QStringList downloadedCatalogFiles = myDir.entryList(QDir::Files);
    foreach (QString fileName, downloadedCatalogFiles) {
        qDebug() << "Parsing file " << fileName;
        QFile catalogPage(fileName);
        catalogPage.open(QFile::ReadOnly | QIODevice::Text);
        QTextStream in(&catalogPage);
        in.setCodec("CP1251");
        QString pageContent = in.readAll();
        parseCatalogPageContent(pageContent);
        catalogPage.close();
    }
}

void Crawler::startDownloadingProjectsLinks()
{
    downloadNextLinkFromQueue();
}

void Crawler::parseCatalogPageContent(QString pageHtml)
{
    QString entityStartMarker("<table width=\"230\" border=\"1\" cellpadding=\"0\" cellspacing=\"0\" bordercolor=\"#B3B3B3\" align=left>");
    QString entityEndMarker("</table></td>");


    int markerFindStartPosition(0);
    while (pageHtml.indexOf(entityStartMarker, markerFindStartPosition) != -1) {

        markerFindStartPosition = pageHtml.indexOf(entityStartMarker, markerFindStartPosition);
        int markerEndPosition = pageHtml.indexOf(entityEndMarker, markerFindStartPosition);
        QString catalogEntityDescription = pageHtml.mid(markerFindStartPosition, markerEndPosition - markerFindStartPosition);

        QString url = "http://plans.ru/" + getTextFromCode(catalogEntityDescription, "project.php?id=", "\"");
        QString catalogImageUrl = "http://plans.ru/" + getTextFromCode(catalogEntityDescription, "images/projects/", "\"");

        //qDebug() << "url = " << url << "    catalogImageUrl = " << catalogImageUrl;
        createRealEstateObject(url, catalogImageUrl);
        addToDownloadList(url);
        addToDownloadList(catalogImageUrl);


        markerFindStartPosition = markerEndPosition + 1;
    }
}

void Crawler::createRealEstateObject(QString linkUrl, QString catalogImageUrl) {
    RealEstateProject *project = new RealEstateProject(this);
    project->setLink(linkUrl);
    project->setCatalogImage(catalogImageUrl);
    realEstateProjectList.append(project);
}

QString Crawler::getTextFromCode(QString string, QString startingMarker, QString breakingMarker) {
    int indexStart = string.indexOf(startingMarker);
    int indexEnd = string.indexOf(breakingMarker, indexStart + 1);
    return string.mid(indexStart, indexEnd - indexStart).trimmed();
}

void Crawler::createDir(QString dirPath) {
    QDir dir(dirPath);
    if (!dir.exists()) {
        dir.mkpath(".");
    }
}

int Crawler::getTypeOfPlan(QString pageContent) {
    if (pageContent.contains(QString::fromUtf8("Проект деревянного дома"))) {
        return 1;
    } else if (pageContent.contains(QString::fromUtf8("Проект кирпичного дома"))) {
        return 2;
    }  else if (pageContent.contains(QString::fromUtf8("Проект бетонного дома"))) {
        return 3;
    }  else if (pageContent.contains(QString::fromUtf8("Проект каркасного дома"))) {
        return 4;
    }  else if (pageContent.contains(QString::fromUtf8("Проект комбинированного дома"))) {
        return 5;
    }  else {
        qWarning() << "Warning, can't get type of the project.";
        return 5;
    }
}

QString Crawler::getProjectId(QString pageContent) {
    QString projectId = getTextFromCode(pageContent, QString::fromUtf8("Проект дома "), "\"");
    projectId.remove(QString::fromUtf8("Проект дома "));
    return projectId;
}

QString Crawler::getProjectIdFromUrl(QString url) {
    QString id("00-00");
    QRegExp rxlen("(\\d\\d-\\d\\d)");
    int pos = rxlen.indexIn(url);
    if (pos > -1) {
        id = rxlen.cap(1);
    } else {
        qWarning() << "Can't get id of the project from the url = " << url;
        qWarning() << "Id set to 00-00";
    }
    return id;
}

void Crawler::saveFileFromReply(QString fileName, QNetworkReply* reply) {
    QFile file(fileName);
    file.open(QFile::WriteOnly);
    file.write(reply->readAll());
    file.close();
}

void Crawler::saveStringToFile(QString fileName, QString string) {
    QFile file(fileName);
    //qDebug() << "Writing project content into file " << fileName << " content " << string.mid(0, 60);
    if (file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        //Stream the QString text to the file.
        //qDebug() << "Writing project page in file " << fileName;
        QTextStream out(&file);
        out.setCodec("UTF-8");
        out << string << endl;     //Use endl for flush.  Does not properly write ű and ő chars.
                                    //Accents missing in file.
        file.close();               //Done with file.
    }
}

void Crawler::addFacadeImageToDownloadQueue(QString projectPageContent) {
    QRegExp rx("/images/f/[^\\\"]+");    // primitive floating point matching
    int count = 0;
    int pos = 0;
    while ((pos = rx.indexIn(projectPageContent, pos)) != -1) {
        QString url = "http://plans.ru/" + projectPageContent.mid(pos, rx.matchedLength());
        addToDownloadList(url);

        ++count;
        pos += rx.matchedLength();
    }
}

void Crawler::addFloorHeightToDownloadQueue(QString projectPageContent) {
    QRegExp rx("/images/v/[^\\\"]+");    // primitive floating point matching
    int count = 0;
    int pos = 0;
    while ((pos = rx.indexIn(projectPageContent, pos)) != -1) {
        QString url = "http://plans.ru/" + projectPageContent.mid(pos, rx.matchedLength());
        addToDownloadList(url);

        ++count;
        pos += rx.matchedLength();
    }
}

void Crawler::addFloorPlanToDownloadQueue(QString projectPageContent) {
    QRegExp rx("/images/projects/[^\"]+");    // primitive floating point matching
    int count = 0;
    int pos = 0;
    while ((pos = rx.indexIn(projectPageContent, pos)) != -1) {
        QString url = "http://plans.ru/" + projectPageContent.mid(pos, rx.matchedLength());
        addToDownloadList(url);

        ++count;
        pos += rx.matchedLength();
    }
}

QString Crawler::getFileNameFromUrl(QString url) {
    QRegExp fileNameRegEx("/([^/]+)$");
    int pos = fileNameRegEx.indexIn(url);
    if (pos > -1) {
        return fileNameRegEx.cap(1);
    }
    return (QString(""));
}

void Crawler::downloadNextLinkFromQueue() {
    if (!downloadList.isEmpty()) {
        QString url = downloadList.at(0);
        //downloadList.removeAt(0);
        manager->get(QNetworkRequest(QUrl(url)));
    }
}
