#ifndef REALESTATEPROJECT_H
#define REALESTATEPROJECT_H

#include <QObject>
#include <QPair>
#include <QtCore>

class RealEstateProject : public QObject
{
    Q_OBJECT
public:
    explicit RealEstateProject(QObject *parent = 0);
    void setId(QString id);
    void setLink(QString url);
    void setCatalogImage(QString url);
    void setType(int type);
    void setTitleImage(QString url);
    void addSideImage(QString url);
    void setArea(QString area);
    void addToDescriptionTable(QString term, QString description);
    void addToFloorDescription(QString term, QString imageUrl);

private:
    QString id;
    QString link;
    QString catalogImage;
    int type;
    QString titleImage;
    QStringList sideImages;
    QString area;
    QList< QPair< QString, QString> > descriptionTable; // term / description
    QList< QPair< QString, QString> > floorDescription; // term / image
};

#endif // REALESTATEPROJECT_H
