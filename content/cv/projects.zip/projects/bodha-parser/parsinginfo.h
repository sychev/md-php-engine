#ifndef PARSINGINFO_H
#define PARSINGINFO_H

#include <QObject>
#include <QMutex>
#include <QStringList>
#include <QMap>
#include <QPair>

class ParsingInfo : public QObject
{
    Q_OBJECT
public:
    explicit ParsingInfo(QObject *parent = 0);
    QString takeFileName();
    void appendFileName(QString fileName);
    bool areAllFilesProcessed() const;
    void resetInfo();
    QString getPrettyStatus() const;
    void setTempDir(QString dirPath);
    QString getTempDir() const;
    void setResultDir(QString dirPath);
    QString getResultDir() const;
    mutable QMutex currentDirMutex;
    void addWordInChart(QString word);
    bool isChartEmpty() const;
    QPair <QString, qint32> takeChartItem();
    void addToListOfUnparsedFiles(QString filePath);
    QStringList getListOfUnparsedFiles();
    static bool isRussianWordLetter(QChar c);
    static bool isRussianWord(QString word);
    
private:
    mutable QMutex mutex;
    QStringList fileNameList;
    qint32 totalFilesCount;
    QString tempDirPath;
    QString resultDirPath;
    QMap <QString, qint32> wordChart;
    bool wordChartCacheDirty;
    QStringList wordChartKeyCache;
    QStringList listOfUnparsedFiles;
};

#endif // PARSINGINFO_H
