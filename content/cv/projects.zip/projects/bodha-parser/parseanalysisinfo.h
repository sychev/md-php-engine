#ifndef PARSEANALYSISINFO_H
#define PARSEANALYSISINFO_H

#include <QObject>
#include <QMutex>

class ParseAnalysisInfo : public QObject
{
    Q_OBJECT
public:
    explicit ParseAnalysisInfo(QObject *parent = 0);
    void resetInfo();
    void increaseDirectoryCounter(qint32 add = 1);
    void increaseFileCounter(qint32 add = 1);
    void increaseParsingSize(quint64 add);
    QString getPrettyStatus() const;
    
private:
    mutable QMutex mutex;
    quint64 totalParsingSize;
    quint32 totalFilesParseCount;
    quint32 totalDirectoriesParseCount;
    static QString orderName(int order);
};

#endif // PARSEANALYSISINFO_H
