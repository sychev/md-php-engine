#include "wordparsingwidget.h"
#include "analysisthread.h"
#include "parseanalysisinfo.h"
#include "parsingthread.h"
#include "parsinginfo.h"
#include <QtGui>
#include <QDesktopServices>
#include <QDateTime>

const int WordParsingWidget::maxNumOfThreads(64);

WordParsingWidget::WordParsingWidget(QWidget *parent) :
    QWidget(parent),
    interfaceUpdateTimer(new QTimer(this)),
    label(new QLabel(tr("<h1>Words parsing module</h1>"), this)),

    sourcePathLineLabel(new QLabel(tr("Path of the library"))),
    sourcePathLineEdit(new QLineEdit(QDesktopServices::storageLocation(QDesktopServices::HomeLocation), this)),
    browseSorcePushButton(new QPushButton(tr("Browse..."), this)),
    sourceLayout(new QHBoxLayout),

    resultParsingPathLabel(new QLabel(tr("Output directory"), this)),
    resultParsingPathLineEdit(new QLineEdit(this)),
    browseResultParsingPathPushButton(new QPushButton(tr("Browse..."), this)),
    parsingLayout(new QHBoxLayout),

    statusLabel(new QLabel(tr("Ready."), this)),
    analyzePushButton(new QPushButton(tr("Analyze"), this)),
    numOfThreadsLabel(new QLabel(tr("Number of parsing threads"), this)),
    numOfThreadsSpinBox(new QSpinBox(this)),
    parsePushButton(new QPushButton(tr("Parse"), this)),
    statusAndActionsLayout(new QHBoxLayout),

    messageLog (new QPlainTextEdit(this)),
    mainLayout(new QVBoxLayout),
    statusLabelUpdateTimer(new QTimer(this)),
    analysisThread(new AnalysisThread(this)),
    parseAnalysisInfo(new ParseAnalysisInfo(this)),
    parsingThread(new ParsingThread(this)),
    parsingInfo(new ParsingInfo(this))
{
    setupLayout();
    setupUIReactions();
    messageLog->setReadOnly(true);
    messageLog->setMaximumBlockCount(500);
}

void WordParsingWidget::setupLayout()
{
    sourceLayout->addWidget(sourcePathLineLabel);
    sourceLayout->addWidget(sourcePathLineEdit);
    sourceLayout->addWidget(browseSorcePushButton);

    parsingLayout->addWidget(resultParsingPathLabel);
    parsingLayout->addWidget(resultParsingPathLineEdit);
    parsingLayout->addWidget(browseResultParsingPathPushButton);

    statusAndActionsLayout->addWidget(statusLabel, 1);
    statusAndActionsLayout->addWidget(analyzePushButton);
    statusAndActionsLayout->addWidget(numOfThreadsLabel);
    statusAndActionsLayout->addWidget(numOfThreadsSpinBox);
    statusAndActionsLayout->addWidget(parsePushButton);

    mainLayout->addWidget(label);
    mainLayout->addLayout(sourceLayout);
    mainLayout->addLayout(parsingLayout);
    mainLayout->addLayout(statusAndActionsLayout);
    mainLayout->addWidget(messageLog);
    setLayout(mainLayout);
}

void WordParsingWidget::onBrowseSourceButtonClicked()
{
    QString parsingPath = QFileDialog::getExistingDirectory(this, tr("Select directory for parsing"),
                                                            getSourcePath());
    QDir path(parsingPath);
    if (!parsingPath.isEmpty() && path.exists()) {
        sourcePathLineEdit->setText(parsingPath);
    } else if (!parsingPath.isEmpty()) {
        addLogMessage(tr("%1 is not a path.").arg(parsingPath));
    }
}

void WordParsingWidget::onBrowseResultButtonClicked()
{
    QString resultPath = QFileDialog::getExistingDirectory(this, tr("Select directory for parsing"),
                                                            getResultPath());
    QDir path(resultPath);
    if (!resultPath.isEmpty() && path.exists()) {
        resultParsingPathLineEdit->setText(resultPath);
    } else if (!resultPath.isEmpty()) {
        addLogMessage(tr("%1 is not a path.").arg(resultPath));
    }

}

void WordParsingWidget::onAnalyzePushButton()
{
    if (analysisThread->isRunning()) {
        analysisThread->askToQuit();
        analyzePushButton->setEnabled(false);
    } else {
        addLogMessage(tr("Start analysis."));
        analysisThread->makeAnalysis(sourcePathLineEdit->text(), parseAnalysisInfo);
    }
}

void WordParsingWidget::updateStatusLabel()
{
    if (analysisThread->isRunning()) {
        statusLabel->setText(parseAnalysisInfo->getPrettyStatus());
    }
    if (parsingThread->isRunning()) {
        statusLabel->setText(parsingInfo->getPrettyStatus());
    }
}

void WordParsingWidget::updateInterfaceElements()
{
    if (analysisThread->isRunning()) {
        analyzePushButton->setText(tr("Stop analysis"));
        parsePushButton->setText(tr("Parse"));
        sourcePathLineEdit->setEnabled(false);
        browseSorcePushButton->setEnabled(false);
        resultParsingPathLineEdit->setEnabled(false);
        browseResultParsingPathPushButton->setEnabled(false);
        parsePushButton->setEnabled(false);
    } else if (parsingThread->isRunning()) {
        analyzePushButton->setText(tr("Analyze"));
        parsePushButton->setText(tr("Stop parsing"));
        analyzePushButton->setEnabled(false);
        sourcePathLineEdit->setEnabled(false);
        browseSorcePushButton->setEnabled(false);
        resultParsingPathLineEdit->setEnabled(false);
        browseResultParsingPathPushButton->setEnabled(false);
    } else {
        analyzePushButton->setText(tr("Analyze"));
        parsePushButton->setText(tr("Parse"));
        analyzePushButton->setEnabled(true);
        parsePushButton->setEnabled(true);
        sourcePathLineEdit->setEnabled(true);
        browseSorcePushButton->setEnabled(true);
        resultParsingPathLineEdit->setEnabled(true);
        browseResultParsingPathPushButton->setEnabled(true);
    }
}

void WordParsingWidget::saveSourcePath(QString path)
{
    QDir parsingPath(sourcePathLineEdit->text());
    if (parsingPath.exists()) {
        QSettings settings(qApp->organizationDomain(), qApp->applicationName());
        settings.setValue("WordParsingWidget/sourcePath", path);
    }
}

void WordParsingWidget::saveResultPath(QString path)
{
    QDir parsingPath(resultParsingPathLineEdit->text());
    if (parsingPath.exists()) {
        QSettings settings(qApp->organizationDomain(), qApp->applicationName());
        settings.setValue("WordParsingWidget/resultPath", path);
    }
}

void WordParsingWidget::saveNumOfThreads(int threads)
{
    if (threads < 1) {
        threads = 1;
    } else if (threads > maxNumOfThreads) {
        threads = maxNumOfThreads;
    }
    QSettings settings(qApp->organizationDomain(), qApp->applicationName());
    settings.setValue("WordParsingWidget/numOfThreads", threads);
}

QString WordParsingWidget::getSourcePath() const
{
        QSettings settings(qApp->organizationDomain(), qApp->applicationName());
        return settings.value("WordParsingWidget/sourcePath",
                                                 QDesktopServices::storageLocation(QDesktopServices::HomeLocation)).toString();
}

QString WordParsingWidget::getResultPath() const
{
        QSettings settings(qApp->organizationDomain(), qApp->applicationName());
        return settings.value("WordParsingWidget/resultPath",
                                                 QDesktopServices::storageLocation(QDesktopServices::HomeLocation)).toString();
}

int WordParsingWidget::getNumOfThreads() const
{
    QSettings settings(qApp->organizationDomain(), qApp->applicationName());
    return settings.value("WordParsingWidget/numOfThreads", 1).toInt();
}

void WordParsingWidget::addLogMessage(QString message)
{
    QDateTime dateTime;
    messageLog->appendPlainText(dateTime.currentDateTime().toString(tr("[hh:mm:ss.zzz] ")) + message);
}

void WordParsingWidget::logAnalyticsResults()
{
    addLogMessage(parseAnalysisInfo->getPrettyStatus());
}

void WordParsingWidget::setupUIReactions()
{
    interfaceUpdateTimer->setInterval(250);
    connect(interfaceUpdateTimer, SIGNAL(timeout()), this, SLOT(updateInterfaceElements()));
    interfaceUpdateTimer->start();

    connect(browseSorcePushButton, SIGNAL(clicked()), this, SLOT(onBrowseSourceButtonClicked()));
    connect(browseResultParsingPathPushButton, SIGNAL(clicked()), this, SLOT(onBrowseResultButtonClicked()));
    connect(analyzePushButton, SIGNAL(clicked()), this, SLOT(onAnalyzePushButton()));
    connect(parsePushButton, SIGNAL(clicked()), this, SLOT(onParseButtonClicked()));

    connect(analysisThread, SIGNAL(finished()), this, SLOT(updateStatusLabel()));
    connect(parsingThread, SIGNAL(finished()), this, SLOT(updateStatusLabel()));

    statusLabelUpdateTimer->setInterval(250);
    connect(statusLabelUpdateTimer, SIGNAL(timeout()), this, SLOT(updateStatusLabel()));

    connect(analysisThread, SIGNAL(started()), statusLabelUpdateTimer, SLOT(start()));
    connect(analysisThread, SIGNAL(finished()), statusLabelUpdateTimer, SLOT(stop()));
    connect(parsingThread, SIGNAL(started()), statusLabelUpdateTimer, SLOT(start()));
    connect(parsingThread, SIGNAL(finished()), statusLabelUpdateTimer, SLOT(stop()));

    connect(analysisThread, SIGNAL(finished()), this, SLOT(logAnalyticsResults()));
    connect(parsingThread, SIGNAL(finished()), this, SLOT(logParsingResults()));

    sourcePathLineEdit->setText(getSourcePath());
    connect(sourcePathLineEdit, SIGNAL(textChanged(QString)), this, SLOT(saveSourcePath(QString)));
    resultParsingPathLineEdit->setText(getResultPath());
    connect(resultParsingPathLineEdit, SIGNAL(textChanged(QString)), this, SLOT(saveResultPath(QString)));
    numOfThreadsSpinBox->setMaximum(maxNumOfThreads);
    numOfThreadsSpinBox->setValue(getNumOfThreads());
    connect(numOfThreadsSpinBox, SIGNAL(valueChanged(int)), this, SLOT(saveNumOfThreads(int)));
}

void WordParsingWidget::logParsingResults()
{
    addLogMessage(tr("Parsing finished."));
}

void WordParsingWidget::onParseButtonClicked()
{
    if (parsingThread->isRunning()) {
        parsingThread->askToQuit();
        parsePushButton->setEnabled(false);
    } else {
        addLogMessage(tr("Start parsing."));
        parsingInfo->setResultDir(resultParsingPathLineEdit->text());
        parsingThread->parse(sourcePathLineEdit->text(), parsingInfo, getNumOfThreads());
    }
}
