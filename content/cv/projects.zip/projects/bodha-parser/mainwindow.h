#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QtGui/QMainWindow>

class MainWidget;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = 0);

protected:
    void closeEvent(QCloseEvent *event);

private:
     void readSettings();
     void writeSettings();
     void restoreAppGeometry();
     void saveAppGeometry();
     MainWidget *mainWidget;
};

#endif // MAINWINDOW_H
