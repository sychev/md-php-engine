#include "parsingworkingthread.h"
#include "parsinginfo.h"

#include <QMutexLocker>
#include <QDir>
#include <QProcess>
#include <QDebug>

ParsingWorkingThread::ParsingWorkingThread(QObject *parent) :
    QThread(parent),
    needToQuit(false)
{
}

ParsingWorkingThread::~ParsingWorkingThread()
{
    QMutexLocker lock(&mutex);
    needToQuit = true;
    lock.unlock();

    wait();
}

void ParsingWorkingThread::parse(ParsingInfo *infoContainerPointer)
{
    if (infoContainerPointer != NULL) {
        infoContainer = infoContainerPointer;
        start(QThread::NormalPriority);
    }
}

void ParsingWorkingThread::run()
{
    parseFiles();
}

void ParsingWorkingThread::parseFiles()
{
    while (!infoContainer->areAllFilesProcessed() && !needToQuit) {
        QString fileName = infoContainer->takeFileName();
        QFile workingFile(fileName);
        QFileInfo workingFileInfo(workingFile);
        QString workingDirName(workingFileInfo.completeBaseName() + '.' + workingFileInfo.suffix() + ".temp");

        QString workingDirPath;
        {
            QDir workingDir(infoContainer->getTempDir());
            workingDir.mkdir(workingDirName);
            workingDir.cd(workingDirName);
            workingDirPath = workingDir.canonicalPath();
        }

        infoContainer->currentDirMutex.lock();
        {
            QProcess extractor;
            QString oldCurrentPath = QDir::current().canonicalPath();
            QDir::setCurrent(workingDirPath);
            QStringList extractorArguments;
            extractorArguments << "e" << "-y" << fileName;
            extractor.execute("7z.exe", extractorArguments);
            QDir::setCurrent(oldCurrentPath);
        }
        infoContainer->currentDirMutex.unlock();

        parseDir(workingDirPath);

        bool removeDirSuccess(false);
        while (!removeDirSuccess) {
            removeDirSuccess = removeDir(workingDirPath);
            if (!removeDirSuccess) {
                msleep(100);
            }
        }
    }
}

void ParsingWorkingThread::askToQuit()
{
    QMutexLocker lock(&mutex);
    needToQuit = true;
}

void ParsingWorkingThread::parseDir(QString dirPath)
{
    if (dirPath.isEmpty()) {
        return;
    }
    QDir dir(dirPath);

    if (dir.exists(dirPath)) {
        Q_FOREACH(QFileInfo info, dir.entryInfoList(QDir::NoDotAndDotDot | QDir::System | QDir::Hidden  | QDir::AllDirs | QDir::Files, QDir::DirsFirst)) {
            if (info.isDir()) {
                parseDir(info.absoluteFilePath());
            }
            else {
                parseFile(info.absoluteFilePath());
            }
        }
    }
}

void ParsingWorkingThread::parseFile(QString filePath) {
    QFile fileForParsing(filePath);
    if (fileForParsing.open(QFile::ReadOnly | QFile::Text)) {
        qDebug() << "File:" << filePath;
        QString line = QString::fromLocal8Bit(fileForParsing.readAll());
        if (line.left(800).toLower().contains("<?xml version=\"1.0\" encoding=\"windows-1251\"?>")) {
            // everything ok, we already read file in local encoding
        } else if (line.left(800).toLower().contains("<?xml version=\"1.0\" encoding=\"utf-8\"?>")) {
            fileForParsing.seek(0);
            line = QString::fromUtf8(fileForParsing.readAll());
        } else {
             infoContainer->addToListOfUnparsedFiles(filePath);
        }

        int bodyStartPosition(line.indexOf("<body>"));
        int bodyEndPosition(line.indexOf("</body>"));
        line = line.mid(bodyStartPosition + 6, bodyEndPosition - bodyStartPosition - 6);

        line.replace(QRegExp("<[^>]*>"), "");
        line = line.left(1000);
        QStringList words = line.split(QRegExp("\\W+"), QString::SkipEmptyParts);
        foreach (QString word, words) {
            infoContainer->addWordInChart(word);
        }
    }
}

bool removeDir(const QString dirName)
{
    if (dirName.isEmpty()) {
        return true;
    }
    bool result(true);
    QDir dir(dirName);

    if (dir.exists(dirName)) {
        Q_FOREACH(QFileInfo info, dir.entryInfoList(QDir::NoDotAndDotDot | QDir::System | QDir::Hidden  | QDir::AllDirs | QDir::Files, QDir::DirsFirst)) {
            if (info.isDir()) {
                result = removeDir(info.absoluteFilePath());
            }
            else {
                QFile::setPermissions(info.absoluteFilePath(), (QFile::Permission)0x7777);
                result = QFile::remove(info.absoluteFilePath());
            }

            if (!result) {
                return result;
            }
        }
        result = dir.rmdir(dirName);
    }
    return result;
}
