#include "aboutwidget.h"

AboutWidget::AboutWidget(QWidget *parent) :
    QWidget(parent)
{
}
