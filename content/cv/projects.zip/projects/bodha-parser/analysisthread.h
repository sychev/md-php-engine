#ifndef ANALYSISTHREAD_H
#define ANALYSISTHREAD_H

#include <QThread>
#include <QMutex>

class ParseAnalysisInfo;
class QString;

class AnalysisThread : public QThread
{
    Q_OBJECT

public:
    AnalysisThread(QObject *parent = 0);
    ~AnalysisThread();
    void makeAnalysis(QString dir, ParseAnalysisInfo* infoContainerPointer);
    void askToQuit();

protected:
    void run();

private:
    ParseAnalysisInfo *infoContainer;
    QString parsingDir;
    void analyzeParsingDir(QString path);
    bool needToQuit;
    mutable QMutex mutex;
};

#endif // ANALYSISTHREAD_H
