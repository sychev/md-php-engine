#include "parseanalysisinfo.h"
#include <QMutexLocker>

ParseAnalysisInfo::ParseAnalysisInfo(QObject *parent) :
    QObject(parent),
    totalParsingSize(0),
    totalFilesParseCount(0),
    totalDirectoriesParseCount(0)
{
}
void ParseAnalysisInfo::resetInfo()
{
    QMutexLocker lock(&mutex);
    totalParsingSize = 0;
    totalFilesParseCount = 0;
    totalDirectoriesParseCount = 0;
}

void ParseAnalysisInfo::increaseDirectoryCounter(qint32 add)
{
    QMutexLocker lock(&mutex);
    totalDirectoriesParseCount += add;
}

void ParseAnalysisInfo::increaseFileCounter(qint32 add)
{
    QMutexLocker lock(&mutex);
    totalFilesParseCount += add;
}

void ParseAnalysisInfo::increaseParsingSize(quint64 add)
{
    QMutexLocker lock(&mutex);
    totalParsingSize += add;
}

QString ParseAnalysisInfo::getPrettyStatus() const
{
    float parsingSize(totalParsingSize);
    float density(parsingSize / totalFilesParseCount);

    int sizeOrder(0);
    while (parsingSize > 1024) {
        ++sizeOrder;
        parsingSize /= 1024;
    }

    int densityOrder(0);
    while (density > 1024) {
        ++densityOrder;
        density /= 1024;
    }

    return QString(tr("Total size for parsing is %1 %2. %3 files in %4 directories. Average %5 %7 per file."))\
            .arg(parsingSize, 0, 'f', 2).arg(orderName(sizeOrder))\
            .arg(totalFilesParseCount).arg(totalDirectoriesParseCount)\
            .arg(density, 0, 'f', 2).arg(orderName(densityOrder));
}

QString ParseAnalysisInfo::orderName(int order)
{
    QString orderName("bytes");
    switch (order) {
    case 0:
        orderName = tr("bytes");
        break;
    case 1:
        orderName = tr("KiB");
        break;
    case 2:
        orderName = tr("MiB");
        break;
    case 3:
        orderName = tr("GiB");
        break;
    case 4:
        orderName = tr("TiB");
        break;
    case 5:
        orderName = tr("PiB");
        break;
    case 6:
        orderName = tr("EiB");
        break;
    default:
        orderName = tr("bytes");
    }
    return orderName;
}
