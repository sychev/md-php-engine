#ifndef PARSINGTHREAD_H
#define PARSINGTHREAD_H

#include "parsingworkingthread.h"

#include <QThread>
#include <QMutex>
#include <QList>

class ParsingInfo;

class ParsingThread : public QThread
{
    Q_OBJECT
public:
    explicit ParsingThread(QObject *parent = 0);
    ~ParsingThread();
    void parse(QString dir, ParsingInfo *infoContainerPointer, int threads = 1);
    void askToQuit();

protected:
    void run();

private:
    QString parsingDir;
    ParsingInfo *infoContainer;
    bool needToQuit;
    int numOfThreads;
    mutable QMutex mutex;
    void runParsingWorkers();
    QList< ParsingWorkingThread* > parsingWorkingThreadList;
    bool areAnyOfThreadIsRunning();
    void constructInfoContainer();
    void addFilesFromDirectoryAndSubdirectories(QString path);
    void createWorkingTempEnvironment();
    void deleteWorkingTempEnvironment();
    static const QString tempDirName;
    void saveResultInFile();
};

#endif // PARSINGTHREAD_H
