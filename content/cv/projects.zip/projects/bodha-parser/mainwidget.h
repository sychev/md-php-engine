#ifndef MAINWIDGET_H
#define MAINWIDGET_H

#include <QTabWidget>

class WordParsingWidget;
class AboutWidget;

class MainWidget: public QTabWidget
{
    Q_OBJECT
public:
    explicit MainWidget(QWidget *parent = 0);

private:
    WordParsingWidget *wordParsingWidget;
    AboutWidget *aboutWidget;
};

#endif // MAINWIDGET_H
