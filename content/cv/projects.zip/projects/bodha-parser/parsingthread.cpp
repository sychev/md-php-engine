#include "parsingthread.h"
#include "parsingworkingthread.h"
#include "parsinginfo.h"

#include <QMutexLocker>
#include <QDir>
#include <QDesktopServices>
#include <QDebug>
#include <QTextCodec>

const QString ParsingThread::tempDirName("parsing-delete-me");

ParsingThread::ParsingThread(QObject *parent) :
    QThread(parent),
    infoContainer(NULL),
    needToQuit(false),
    numOfThreads(1)
{
}

ParsingThread::~ParsingThread()
{
    QMutexLocker lock(&mutex);
    needToQuit = true;
    lock.unlock();

    wait();
}

void ParsingThread::run()
{
    constructInfoContainer();
    if (needToQuit) {
        deleteWorkingTempEnvironment();
        return;
    }
    runParsingWorkers();
    deleteWorkingTempEnvironment();
    qDebug() << "End of parsing thread.";
}

void ParsingThread::runParsingWorkers()
{
    for (int i = 0; i < numOfThreads; ++i) {
        ParsingWorkingThread *thread = new ParsingWorkingThread;
        parsingWorkingThreadList.append(thread);
    }
    foreach (ParsingWorkingThread *thread, parsingWorkingThreadList) {
        thread->parse(infoContainer);
    }

    while (areAnyOfThreadIsRunning()) {
        if (needToQuit) {
            foreach (ParsingWorkingThread *thread, parsingWorkingThreadList) {
                thread->askToQuit();
            }
        }
        msleep(200);
    }

    foreach (ParsingWorkingThread *thread, parsingWorkingThreadList) {
        thread->deleteLater();
    }
    parsingWorkingThreadList.clear();
    saveResultInFile();
}

bool ParsingThread::areAnyOfThreadIsRunning()
{
    bool threadsAreWorking(false);
    foreach (ParsingWorkingThread *thread, parsingWorkingThreadList) {
        if (thread->isRunning()) {
            threadsAreWorking = true;
        }
    }
    return threadsAreWorking;
}

void ParsingThread::parse(QString dir, ParsingInfo *infoContainerPointer, int threads)
{
    if (infoContainerPointer != NULL) {
        numOfThreads = threads;
        if (numOfThreads < 1) {
            numOfThreads = 1;
        }
        infoContainer = infoContainerPointer;
        parsingDir = dir;
        infoContainer->resetInfo();
        needToQuit = false;

        deleteWorkingTempEnvironment();
        createWorkingTempEnvironment();
        start(QThread::NormalPriority);
    }
}

void ParsingThread::askToQuit()
{
    QMutexLocker lock(&mutex);
    needToQuit = true;
}

void ParsingThread::constructInfoContainer()
{
    addFilesFromDirectoryAndSubdirectories(parsingDir);
}

void ParsingThread::addFilesFromDirectoryAndSubdirectories(QString path)
{
    QDir dir(path);
    if (dir.exists()) {
        QFileInfoList fileInfoList(dir.entryInfoList(QDir::Files | QDir::Dirs | QDir::NoSymLinks | QDir::NoDotAndDotDot));
        foreach (QFileInfo fileInfo, fileInfoList) {
            if (fileInfo.exists()) {
                if (needToQuit) {
                    return;
                }
                if (fileInfo.isDir()) {
                    addFilesFromDirectoryAndSubdirectories(fileInfo.canonicalFilePath());
                } else if (fileInfo.isFile()) {
                    infoContainer->appendFileName(fileInfo.canonicalFilePath());
                }
            }
        }
    }
}
void ParsingThread::createWorkingTempEnvironment()
{
    QDir tempDir(infoContainer->getResultDir());
    tempDir.mkdir(tempDirName);
    tempDir.cd(tempDirName);
    infoContainer->setTempDir(tempDir.canonicalPath());
}

void ParsingThread::deleteWorkingTempEnvironment()
{
    QDir::setCurrent(infoContainer->getResultDir());
    removeDir(infoContainer->getTempDir());
}

void ParsingThread::saveResultInFile() {
    QFile resultFile(infoContainer->getResultDir() + "/word-parsing-result.txt");
    if (resultFile.open(QFile::WriteOnly | QFile::Truncate)) {
        QTextStream stream(&resultFile);
        stream.setCodec(QTextCodec::codecForName("utf-8"));
        while (!infoContainer->isChartEmpty()) {
            QPair<QString, qint32> wordCount = infoContainer->takeChartItem();
            stream << wordCount.first << ',' << wordCount.second << '\n';
        }

        QStringList list = infoContainer->getListOfUnparsedFiles();
        if (!list.isEmpty()) {
            stream << "List of unparsed files\n";
            foreach (QString filePath, list) {
                stream << filePath << '\n';
            }
        }
    }
    infoContainer->resetInfo();
}
