#include <QtGui>

#include "mainwindow.h"
#include "mainwidget.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent),
      mainWidget(new MainWidget(this))
{
    setMinimumSize(QSize(640, 480));
    readSettings();

    this->setCentralWidget(mainWidget);

    setWindowTitle(qApp->applicationName());
}

void MainWindow::closeEvent(QCloseEvent *event)
{
    writeSettings();
    event->accept();
}

void MainWindow::readSettings()
{
    restoreAppGeometry();
}

void MainWindow::writeSettings()
{
    saveAppGeometry();
}

void MainWindow::restoreAppGeometry()
{
    QSettings settings(qApp->organizationDomain(), qApp->applicationName());
    bool geometryWasRestored(false);
    if (settings.value("MainWindow/geometry").toByteArray().size() != 0) {
        geometryWasRestored = restoreGeometry(settings.value("MainWindow/geometry").toByteArray());
    }
    if(!geometryWasRestored) {
        QRect availableRect = qApp->desktop()->availableGeometry();
        if ((availableRect.width() > 800) && (availableRect.height() > 600)) {
            setGeometry(availableRect.x() + 60, availableRect.y() + 60, availableRect.width() - 120, availableRect.height() - 120);
        } else {
            setGeometry(availableRect);
        }
    }
}

void MainWindow::saveAppGeometry()
{
    QSettings settings(qApp->organizationDomain(), qApp->applicationName());
    settings.setValue("MainWindow/geometry", saveGeometry());
}
