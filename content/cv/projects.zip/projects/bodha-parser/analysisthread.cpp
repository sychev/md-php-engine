#include <QDir>
#include <QMutexLocker>
#include "analysisthread.h"
#include "parseanalysisinfo.h"

AnalysisThread::AnalysisThread(QObject *parent):
    QThread(parent),
    needToQuit(false)
{
}

AnalysisThread::~AnalysisThread()
{
    QMutexLocker lock(&mutex);
    needToQuit = true;
    lock.unlock();

    wait();
}

void AnalysisThread::makeAnalysis(QString dir, ParseAnalysisInfo *infoContainerPointer)
{
    if (infoContainerPointer != NULL) {
        infoContainer = infoContainerPointer;
        parsingDir = dir;
        infoContainer->resetInfo();
        needToQuit = false;
        start(QThread::LowPriority);
    }
}

void AnalysisThread::run()
{
    analyzeParsingDir(parsingDir);
}

void AnalysisThread::analyzeParsingDir(QString path)
{
    QDir dir(path);
    if (dir.exists()) {
        infoContainer->increaseDirectoryCounter();
        QFileInfoList fileInfoList(dir.entryInfoList(QDir::Files | QDir::Dirs | QDir::NoSymLinks | QDir::NoDotAndDotDot));
        foreach (QFileInfo fileInfo, fileInfoList) {
            if (fileInfo.exists()) {
                if (needToQuit) {
                    return;
                }
                if (fileInfo.isDir()) {
                    analyzeParsingDir(fileInfo.canonicalFilePath());
                } else if (fileInfo.isFile()) {
                    infoContainer->increaseFileCounter();
                    infoContainer->increaseParsingSize(fileInfo.size());
                }
            }
        }
    }
}

void AnalysisThread::askToQuit()
{
    QMutexLocker lock(&mutex);
    needToQuit = true;
}
