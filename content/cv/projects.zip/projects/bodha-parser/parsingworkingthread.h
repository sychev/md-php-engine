#ifndef PARSINGWORKINGTHREAD_H
#define PARSINGWORKINGTHREAD_H

#include <QThread>
#include <QMutex>

class ParsingInfo;
bool removeDir(const QString dirName);

class ParsingWorkingThread : public QThread
{
    Q_OBJECT
public:
    explicit ParsingWorkingThread(QObject *parent = 0);
    ~ParsingWorkingThread();
    void parse (ParsingInfo *infoContainerPointer);
    void askToQuit();

protected:
    void run();

private:
    mutable QMutex mutex;
    bool needToQuit;
    ParsingInfo *infoContainer;
    void parseFiles();
    void parseDir(QString dirPath);
    void parseFile(QString filePath);
};

#endif // PARSINGWORKINGTHREAD_H
