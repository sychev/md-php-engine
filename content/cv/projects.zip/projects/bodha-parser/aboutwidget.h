#ifndef ABOUTWIDGET_H
#define ABOUTWIDGET_H

#include <QWidget>

class AboutWidget : public QWidget
{
    Q_OBJECT
public:
    explicit AboutWidget(QWidget *parent = 0);
    
signals:
    
public slots:
    
};

#endif // ABOUTWIDGET_H
