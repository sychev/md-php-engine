#include <QtGui/QApplication>
#include "mainwindow.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    a.setApplicationName("Bodha-parser");
    a.setApplicationVersion("0.1");
    a.setOrganizationName("Alex Sychev");
    a.setOrganizationDomain("sychev.com");
    MainWindow w;
    w.show();
    
    return a.exec();
}
