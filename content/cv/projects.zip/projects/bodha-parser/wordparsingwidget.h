#ifndef WORDPARSINGWIDGET_H
#define WORDPARSINGWIDGET_H

#include <QWidget>

class QLabel;
class QVBoxLayout;
class QHBoxLayout;
class QLineEdit;
class QPushButton;
class AnalysisThread;
class ParseAnalysisInfo;
class QPlainTextEdit;
class QString;
class ParsingThread;
class ParsingInfo;
class QSpinBox;

class WordParsingWidget : public QWidget
{
    Q_OBJECT
public:
    explicit WordParsingWidget(QWidget *parent = 0);
    
private slots:
    void onBrowseSourceButtonClicked();
    void onBrowseResultButtonClicked();
    void onAnalyzePushButton();
    void onParseButtonClicked();
    void updateStatusLabel();
    void updateInterfaceElements();
    void saveSourcePath(QString path);
    void saveResultPath(QString path);
    void saveNumOfThreads(int threads);
    void logAnalyticsResults();
    void logParsingResults();

private:
    QTimer *interfaceUpdateTimer;
    QLabel *label;
    QLabel *sourcePathLineLabel;
    QLineEdit *sourcePathLineEdit;
    QPushButton *browseSorcePushButton;
    QHBoxLayout *sourceLayout;

    QLabel *resultParsingPathLabel;
    QLineEdit *resultParsingPathLineEdit;
    QPushButton *browseResultParsingPathPushButton;
    QHBoxLayout *parsingLayout;

    QLabel *statusLabel;
    QPushButton *analyzePushButton;
    QLabel *numOfThreadsLabel;
    QSpinBox *numOfThreadsSpinBox;
    QPushButton *parsePushButton;
    QHBoxLayout *statusAndActionsLayout;

    QPlainTextEdit *messageLog;

    QVBoxLayout *mainLayout;
    void setupLayout();

    QTimer *statusLabelUpdateTimer;
    AnalysisThread *analysisThread;
    ParseAnalysisInfo *parseAnalysisInfo;

    QString getSourcePath() const;
    QString getResultPath() const;
    int getNumOfThreads() const;
    void addLogMessage(QString message);
    void setupUIReactions();

    ParsingThread *parsingThread;
    ParsingInfo *parsingInfo;
    static const int maxNumOfThreads;
//    QTimer *parsingLogUpdateTimer;
};

#endif // WORDPARSINGWIDGET_H
