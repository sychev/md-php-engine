#include "parsinginfo.h"
#include <QStringList>

ParsingInfo::ParsingInfo(QObject *parent) :
    QObject(parent),
    totalFilesCount(0)
{
}

QString ParsingInfo::takeFileName()
{
    QMutexLocker lock(&mutex);
    QString fileName(fileNameList.takeFirst());
    return fileName;
}

void ParsingInfo::appendFileName(QString fileName)
{
    QMutexLocker lock(&mutex);
    fileNameList.append(fileName);
    totalFilesCount = fileNameList.size();
}

bool ParsingInfo::areAllFilesProcessed() const
{
    QMutexLocker lock(&mutex);
    bool allFilesProcessed = fileNameList.isEmpty();
    return allFilesProcessed;
}

void ParsingInfo::resetInfo()
{
    QMutexLocker lock(&mutex);
    fileNameList.clear();
    totalFilesCount = 0;
    listOfUnparsedFiles.clear();
    wordChartCacheDirty = true;
    wordChartKeyCache.clear();
}

QString ParsingInfo::getPrettyStatus() const
{
    QMutexLocker lock(&mutex);
    qint32 remainFilesCount(fileNameList.size());
    float complete(100 - (float)remainFilesCount / totalFilesCount * 100);
    QString status(QString("%1% complete. %2 files done. %3 files remain.")\
                   .arg(complete, 0, 'f', 2).arg(totalFilesCount - remainFilesCount).arg(remainFilesCount));
    return status;
}

void ParsingInfo::setTempDir(QString dirPath)
{
    QMutexLocker lock(&mutex);
    tempDirPath = dirPath;
}

QString ParsingInfo::getTempDir() const
{
    QMutexLocker lock(&mutex);
    return tempDirPath;
}

void ParsingInfo::setResultDir(QString dirPath)
{
    QMutexLocker lock(&mutex);
    resultDirPath = dirPath;
}

QString ParsingInfo::getResultDir() const
{
    QMutexLocker lock(&mutex);
    return resultDirPath;
}

void ParsingInfo::addWordInChart(QString word) {
    if ((word.size() < 2) || (!word.isSimpleText())) {
        return;
    }

    QMutexLocker lock(&mutex);
    word = word.toLower();
    if (wordChart.contains(word)) {
        ++wordChart[word];
    } else {
        wordChart.insert(word, 1);
        wordChartCacheDirty = true;
    }
}

bool ParsingInfo::isChartEmpty() const {
    QMutexLocker lock(&mutex);
    return wordChart.isEmpty();
}

QPair <QString, qint32> ParsingInfo::takeChartItem()
{
    QMutexLocker lock(&mutex);
    QString key;
    qint32 value(0);
    if (!wordChart.isEmpty()) {
        if (wordChartCacheDirty) {
            wordChartKeyCache = wordChart.keys();
            wordChartCacheDirty = false;
        }
        key = wordChartKeyCache.takeFirst();
        value = wordChart.take(key);
    }
    return QPair<QString, qint32>(key, value);
}

void ParsingInfo::addToListOfUnparsedFiles(QString filePath)
{
    listOfUnparsedFiles.append(filePath);
}

QStringList ParsingInfo::getListOfUnparsedFiles()
{
    return listOfUnparsedFiles;
}


bool ParsingInfo::isRussianWordLetter(QChar c) {
    return (((c > QChar('�')) && (c < QChar('�'))) || (c == QChar('�')) ||
            ((c > QChar('�')) && (c < QChar('�'))) || (c == QChar('�')) ||
            (c == QChar('-')));
}

bool ParsingInfo::isRussianWord(QString word)
{
    for (int i = 0; i < word.size(); ++i) {
        if (!isRussianWordLetter(word.at(i))) {
            return false;
        }
    }
    return true;
}
