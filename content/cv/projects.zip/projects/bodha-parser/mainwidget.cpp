#include <QtGui>

#include "mainwidget.h"
#include "wordparsingwidget.h"
#include "aboutwidget.h"

MainWidget::MainWidget(QWidget *parent) :
    QTabWidget(parent),
    wordParsingWidget (new WordParsingWidget(this)),
    aboutWidget (new AboutWidget(this))
{
    addTab(wordParsingWidget, "Words");
    addTab(aboutWidget, "About");
}
